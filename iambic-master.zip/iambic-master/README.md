PA3HCM's simple Arduino iambic keyer
====================================

As modified by Antti OH3HMU
