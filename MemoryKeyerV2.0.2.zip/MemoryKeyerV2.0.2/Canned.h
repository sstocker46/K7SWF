/******************************************************** 
 * Canned.h
 * Four Default canned messages for the arduino memory keyer
 * Each can be up to 50 characters. Also other defaults that
 * might be changed by a user.
 * wb8nbs@gmail.com
 * May 2014
 *******************************************************/

#include <avr/pgmspace.h>

// the following sets up defaults for the four memory messages.
// Each can be 50 characters, the 51st char is the strings trailing null.
// Normally all lower case, upper case letters will not have an inter-character space 
// so you can build prosigns, for instance As will run together dit dah dit dit dit
static const prog_uchar cMessg[4][51] PROGMEM = {
  "mem 1 ",                          // Message 0, button 1
  "mem 2 ",                          // Message 1, button 2
  "mem 3 ",                          // Message 2, button 3
  "mem 4 "                           // Message 3, button 4
};

const unsigned int DEFAULTTONE = 440;   // side tone frequency
const int MAXTONE = 1500;            // highest allowed sidetone freq
const int MINTONE = 100;             // lowest allowed sidetone freq
const unsigned int MIDTONE = 350;    // middle tone announce frequency
const unsigned int LOWTONE = 280;    // low tone announce frequency

const int DEFAULTSPEED = 17;         // default Words Per Minute
const int MAXWPM = 50;               // maximum WPM speed allowed
const int MINWPM = 10;               // minimum WPM speed allowed

const int PRACPAUSE = 3;             // # spaces between 5 char practice groups

// # idle element periods (-1) before a character space is declared
const int CSPACEWAIT = 2;            
// # idle element periods (-1) before a word space is declared
const int WSPACEWAIT = 6;            
const int MAXLINE = 72;              // # chars before a linefeed on serial console

const int MAXQ = 32;                 // sets size of transmit queue buffer

/* useful information:

  PS2 keyboard library from http://playground.arduino.cc/Main/PS2Keyboard
  atmega328 notes (uno, duemilanova, et al.) from the above web page:
  data pin can be any available digital but clock must be D2 or D3 for the interrupt to work.
  PS2 six pin mini DIN connector is wired pin 1 data, pin 3 ground, pin 5 clock, pin 4 +5 volts
  Looking at face of *Female* PS2 Connector:
      6  k  5 
         e          
     4   y    3
   
       2    1 
 
 Analog button switch hookup:
 One side has 10k resistor to +5 and is also connected to Arduino analog pin. Other side 
 connected to ground. Connect a 0.01 microfarad cap across the switch.
 Note any unterminated Analog inputs float to about half scale and will hang the sketch.
 */
